namespace TestZone.Gusta;

public static class ForeachValue
{
    private const char Separador = ';';

    // modificadores de acesso
    // public = todo mundo vê
    // private = só a classe vê

    // Tipos de valor vs Tipos de referência

    // Escopo: alcance de visibilidade de uma variável

    // var myArr = new int[4];
    // tipo com tamanho N bytes
    // 100: [100 + 0N] [100 + 1N] [100 + 2N] [100 + 3N]

    public static string SomaDoublesEscritos(string listaDoubles, string divisor, out decimal final)
    {
        // Console.WriteLine(Name);

        // Divide a entrada em valores individuais
        var valoresString = listaDoubles.Split(Separador); // IEnumerable

        // é possível adicionar num array, mas não é recomendado
        // string[] asdf = new[] { "hello" };
        // var asdf = valoresString.Append("123.321");

        // Converte os valores para decimal e armazena em uma lista
        var meusValores = new List<decimal>();
        // [] Count 0; Capacity 1

        foreach (var valorString in valoresString)
        {
            if (decimal.TryParse(valorString, out var valor))
            {
                meusValores.Add(valor);
                //1 [val0] Count  1, capacity 1
                //2 -> [val0] [val1] count 2, capacity 2
                //3 -> [val0] [val1] [val2] [] count 3, capacity 4
                //4 -> [val0] [val1] [val2] [val3] count 4 cap 4
                //5 -> [val0] [val1] [val2] [val3] [val4] [] [] [] count 5 cap 5
            }
        }

        // decimal inicial = 0;

        // Chama a função "Soma" com os valores informados pelo usuário
        var total = Soma(meusValores);

        // Verifica o valor total e exibe a mensagem correspondente
        if (total > 9000)
        {
            final = 9000;
            return "Over nine thousand";
        }

        var mensagem = total >= 30 ? "Caro pra caramba" : "De boa";

        // var n1 = Math.Round(total);
        // var n2 = Convert.ToDouble(divisor);
        // final = n1 / n2;

        final = total;
        return mensagem;
    }

    private static decimal Soma(List<decimal> valores)
    {
        var total = 0m;
        var totalDouble = 0d;

        foreach (var valor in valores)
        {
            totalDouble += (double)valor; // casting
            total += valor;
        }

        // var emptyArr = new int[3];
        // [4bytes] [4bytes] [4bytes] //

        // var forTotal = 0.0;

        for (var index = 0; index < valores.Count; index++)
        {
            // var kkkk = valores.Capacity;

            // forTotal += valores[index];
            // valores[0];
            // valores[1];
            // valores[2];
        }

        // var soma = valores.Sum();

        return total;
    }
}


