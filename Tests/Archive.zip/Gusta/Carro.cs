namespace TestZone.Gusta;

public class Carro
{
    public static int NumeroDeRodas { get; } = 4;
    public string Modelo { get; set; }
    public string Fabricante { get; init; }
    private DateTime AnoFabricacao { get; set; }

    public Dictionary<int, string> Donos { get; set; } = new();
}

public class UseCar
{
    public void MyMethod()
    {
        var carro = new Carro
        {
            Modelo = "Fiesta",
            Fabricante = "Ford"
        };

        carro.Donos = new Dictionary<int, string>
        {
            { 1, "Paulo" },
            { 2, "Miguel" }
        };

        string dono;
        if (carro.Donos.TryGetValue(90, out var value))
        {
            dono = value;
        }
    }
}
