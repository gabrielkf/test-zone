using TestZone.Gusta;

namespace TestZone.Gustest;

public class ForeachValueTest
{
    /**
     * AAA
     * Arrange
     * Act
     * Assert
     */
    [Fact]
    public void SomaDoublesEscritos_IntanciasDevemSerDiferentes_ComIgualdade()
    {
        // arrange
        // var reference1 = new ForeachValue();
        // var reference2 = new ForeachValue();

        var value1 = 300;
        var value2 = 300;

        var str1 = "hello";
        var str2 = "hello";

        // assert
        Assert.Equal(value1, value2);
        Assert.Equal(str1, str2);
        // Assert.False(reference1 == reference2);
    }

    [Fact]
    public void SomaDoublesEscritos_RetornaOverNineThousand()
    {
        // arrange
        var entrada1 = "123.234,234.345,456.567";
        var esperado1 = "Over nine thousand";

        // var entrada2 = "2.00,3.00,4.00";
        // var esperado2 = "De boa";

        // act
        var resultado1 = ForeachValue.SomaDoublesEscritos(entrada1, "1.0", out var total);
        // var resultado2 = ForeachValue.SomaDoublesEscritos(entrada2, "1.0");

        // assert
        Assert.Equal(esperado1, resultado1);
        Assert.Equal(9000, total);
    }

    [Theory]
    [InlineData("1,1;2,2", "De boa", 3.3)]
    [InlineData("20,00;53,00", "Caro pra caramba", 73.00)]
    [InlineData("123,234;234,345;456,567;8500", "Over nine thousand", 9000)]
    public void SomaDoublesEscritos_RetornaFrase_DeAcordoComValor(string doubleList, string esperado, decimal totalEsperado)
    {
        // act
        var resultado = ForeachValue.SomaDoublesEscritos(doubleList, "1.0", out var total);

        // assert
        Assert.Equal(esperado, resultado);
        Assert.Equal(totalEsperado, total);
    }
}
